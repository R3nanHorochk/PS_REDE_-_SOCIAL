/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication1;

/**
 *
 * @author Renan
 */
public class Pessoa {
        private String nome;
	private int Idade;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getIdade() {
		return Idade;
	}
	public void setIdade(int idade) {
		Idade = idade;
	}

    public Pessoa(String nome, int Idade) {
        this.nome = nome;
        this.Idade = Idade;
    }

    @Override
    public String toString() {
        return "Pessoa{" + "nome=" + nome + ", Idade=" + Idade + '}';
    }
        
}
